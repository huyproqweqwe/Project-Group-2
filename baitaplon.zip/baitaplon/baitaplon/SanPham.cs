﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baitaplon
{
    public partial class SanPham : Form
    {
        public SanPham()
        {
            InitializeComponent();
        }
        SqlConnection conn;
        SqlCommand cmd;

        private void SanPham_Load(object sender, EventArgs e)
        {
            HienThi();
        }
        void KetNoi()
        {
            String str_con = @"Data Source=QUANGKHU\QUANGKHU;Initial Catalog=QuanLyMM;Integrated Security=True;Encrypt=True";
            conn = new SqlConnection(str_con);
            conn.Open();
        }
        void HienThi()
        {
            KetNoi();
            String str_hienthi = "SELECT * FROM SanPham";
            cmd = new SqlCommand(str_hienthi, conn);
            SqlDataAdapter sqla = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sqla.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMa.Text))
            {
                MessageBox.Show("Vui lòng chọn sản phẩm để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            KetNoi();
            String str_xoa = "DELETE FROM SanPham WHERE MaSanPham=@masp";
            SqlCommand cmd2 = new SqlCommand(str_xoa, conn);
            cmd2.Parameters.AddWithValue("@masp", txtMa.Text);

            int sl = cmd2.ExecuteNonQuery();
            if (sl > 0)
                MessageBox.Show("Xóa sản phẩm thất bại!", "Thông báo");
            else
                MessageBox.Show("Xóa sản phẩm thành công", "Thông báo");

            HienThi();
            conn.Close();
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMa.Text))
            {
                MessageBox.Show("Vui lòng chọn sản phẩm để cập nhật.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            KetNoi();
            String str_sua = "UPDATE SanPham SET TenSanPham=@tensp, MoTa=@mota, Gia=@gia, SoLuongTon=@sl, MaNhaCungCap=@mancc, LoaiSanPham=@loaisp, MauSac=@mau WHERE MaSanPham=@masp";

            SqlCommand cmd2 = new SqlCommand(str_sua, conn);
            cmd2.Parameters.AddWithValue("@masp", txtMa.Text);
            cmd2.Parameters.AddWithValue("@tensp", txtTen.Text);
            cmd2.Parameters.AddWithValue("@mota", txtMoTa.Text);
            cmd2.Parameters.AddWithValue("@gia", Convert.ToDecimal(txtGia.Text));
            cmd2.Parameters.AddWithValue("@sl", Convert.ToInt32(txtSoLuong.Text));
            cmd2.Parameters.AddWithValue("@mancc", txtNCC.Text);
            cmd2.Parameters.AddWithValue("@loaisp", cboLoaiSP.Text);
            cmd2.Parameters.AddWithValue("@mau", cboMauSac.Text);

            int sl = cmd2.ExecuteNonQuery();
            if (sl > 0)
                MessageBox.Show("Cập nhật sản phẩm thất bại. Vui lòng kiểm tra lại thông tin!", "Thông báo");
            else
                MessageBox.Show("Cập nhật sản phẩm thành công!", "Thông báo");

            HienThi();
            conn.Close();
        }

        private void btnXuat_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để xuất.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Excel.Application excelApp = new Excel.Application();
            excelApp.Visible = false;

            Excel.Workbook workbook = excelApp.Workbooks.Add(Missing.Value);
            Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];
            worksheet.Name = "SanPhamData";

            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                worksheet.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value?.ToString() ?? "";
                }
            }

            worksheet.Columns.AutoFit();

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel Files|*.xlsx;*.xls",
                Title = "Lưu file Excel",
                FileName = "SanPhamData.xlsx"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                workbook.SaveAs(saveFileDialog.FileName);
                MessageBox.Show("Xuất dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            workbook.Close(false, Missing.Value, Missing.Value);
            excelApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            KetNoi();


            decimal gia;
            int sl;


            if (!decimal.TryParse(txtGia.Text, out gia))
            {
                MessageBox.Show("Giá không hợp lệ. Vui lòng nhập một số hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (!int.TryParse(txtSoLuong.Text, out sl))
            {
                MessageBox.Show("Số lượng không hợp lệ. Vui lòng nhập một số nguyên hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            String str_them = "INSERT INTO SanPham (MaSanPham, TenSanPham, MoTa, Gia, SoLuongTon, MaNhaCungCap, LoaiSanPham, MauSac) " +
                              "VALUES (@masp, @tensp, @mota, @gia, @sl, @mancc, @loaisp, @mau)";

            SqlCommand cmd2 = new SqlCommand(str_them, conn);
            cmd2.Parameters.AddWithValue("@masp", txtMa.Text);
            cmd2.Parameters.AddWithValue("@tensp", txtTen.Text);
            cmd2.Parameters.AddWithValue("@mota", txtMoTa.Text);
            cmd2.Parameters.AddWithValue("@gia", gia);
            cmd2.Parameters.AddWithValue("@sl", sl);
            cmd2.Parameters.AddWithValue("@mancc", txtNCC.Text);
            cmd2.Parameters.AddWithValue("@loaisp", cboLoaiSP.Text);
            cmd2.Parameters.AddWithValue("@mau", cboMauSac.Text);


            int slKetQua = cmd2.ExecuteNonQuery();

            if (slKetQua > 0)
                MessageBox.Show("Thêm sản phẩm thất bại!", "Thông báo");
            else
                MessageBox.Show("Thêm sản phẩm thành công!", "Thông báo");

            HienThi();
            conn.Close();
        }

        private void btnTim_Click(object sender, EventArgs e)
        {

            TimKiemSP timKiemSP = new TimKiemSP();
            timKiemSP.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
             Application.Exit();
        }
    }
    }
}
