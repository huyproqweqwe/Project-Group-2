﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baitaplon
{
    internal class Function
    {
        public static SqlConnection Conn;

        public static void Connect()
        {
            String src = @"Data Source=QUANGKHU\QUANGKHU;Initial Catalog=QuanLyMM;Integrated Security=True;Encrypt=True";
            Conn = new SqlConnection(src);
            Conn.Open();
        }

        public static void Disconnect()
        {
            if (Conn != null && Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }
        }

        public static DataTable GetDataToTable(string query)
        {
            DataTable table = new DataTable();
            try
            {
                Connect();
                SqlDataAdapter dap = new SqlDataAdapter(query, Conn);
                dap.Fill(table);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Disconnect();
            }
            return table;
        }

        public static bool CheckKey(string sql)
        {
            DataTable table = new DataTable();
            try
            {
                Connect();
                SqlDataAdapter dap = new SqlDataAdapter(sql, Conn);
                dap.Fill(table);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Disconnect();
            }
            return table.Rows.Count > 0;
        }

        public static void RunSQL(string sql)
        {
            try
            {
                Connect();
                SqlCommand cmd = new SqlCommand(sql, Conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Disconnect();
            }
        }

        public static void RunSqlDel(string sql)
        {
            try
            {
                Connect();
                SqlCommand cmd = new SqlCommand(sql, Conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Dữ liệu đang được dùng, không thể xoá...", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                Disconnect();
            }
        }

        public static void ExecuteSQL(string sql)
        {
            try
            {
                Connect();
                SqlCommand cmd = new SqlCommand("SET NUMERIC_ROUNDABORT OFF; " + sql, Conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Disconnect();
            }
        }
    }
}

