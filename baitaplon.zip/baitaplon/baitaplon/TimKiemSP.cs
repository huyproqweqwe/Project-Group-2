﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace baitaplon
{
    public partial class TimKiemSP : Form
    {
        public TimKiemSP()
        {
            InitializeComponent();
        }
        private void TimKiemSP_Load(object sender, EventArgs e)
        {

            Function.Connect();
            LoadData();

        }
        private void LoadData()
        {

            string query = "SELECT * FROM SanPham";
            DataTable customerTable = Function.GetDataToTable(query);

            dataGridView1.DataSource = customerTable;
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            string searchValue = txtND.Text.Trim();

            if (!string.IsNullOrEmpty(searchValue))
            {

                string query = "SELECT * FROM SanPham WHERE 1=1";


                if (MaMh.Checked)
                {
                    query += $" AND MaSanPham LIKE '%{searchValue}%'";
                }
                else if (Tenmh.Checked)
                {
                    query += $" AND TenSanPham LIKE N'%{searchValue}%'";
                }
                else if (MauSac.Checked)
                {
                    query += $" AND MauSac LIKE N'%{searchValue}%'";
                }

                DataTable customerTable = Function.GetDataToTable(query);

                if (customerTable.Rows.Count > 0)
                {
                    dataGridView1.DataSource = customerTable;
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("Không tìm thấy sản phẩm tương ứng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập thông tin tìm kiếm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
